SENS POZITIV — prototip de pagină pentru campania către deputați

CE FACE
- Pagina web responsive, în română.
- Arată mesajul integral înainte de trimitere.
- Cere confirmarea explicită că utilizatorul a citit și aprobă mesajul.
- Pregătește un email în aplicația de email sau Gmail.
- Oferă copierea scrisorii.
- Nu trimite automat și nu stochează datele utilizatorului.

CE TREBUIE COMPLETAT ÎNAINTE DE PUBLICARE
1. În index.html, înlocuiește rezumatul legislativ și textul din textarea cu formularea finală aprobată de Sens Pozitiv.
2. Înlocuiește RECIPIENTS cu adresele publice, verificate, ale deputaților vizați.
3. Editează SUBJECT dacă este necesar.
4. Testează butoanele pe iPhone și desktop, cu cel puțin două aplicații de email.
5. Pentru un număr mare de destinatari, împarte lista în grupuri; linkurile mailto pot deveni prea lungi și unele aplicații pot limita numărul destinatarilor.

PUBLICARE GRATUITĂ PE GITHUB PAGES
1. Creează sau autentifică-te într-un cont GitHub.
2. Creează un repository PUBLIC, de exemplu: campanie-psiholog-16.
3. Încarcă index.html în rădăcina repository-ului.
4. Deschide Settings → Pages.
5. La Build and deployment, alege Deploy from a branch; selectează branch-ul main și folderul /(root), apoi Save.
6. După publicare, GitHub va afișa linkul site-ului, de forma https://NUME-UTILIZATOR.github.io/campanie-psiholog-16/
Documentație oficială: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

IMPORTANT
- Acesta este un prototip, nu o campanie gata de lansare: textul și destinatarii sunt marcate intenționat ca nefinalizate.
- În varianta actuală, utilizatorul apasă personal butonul Trimite în aplicația de email. Nu există trimitere automată de pe un server.
- GitHub Pages este hosting static. Vizitele pot genera loguri tehnice, inclusiv adresa IP, conform documentației GitHub.
- Nu colecta adresele personale ale susținătorilor dacă nu ai nevoie de ele. În acest prototip, adresa este folosită numai local pentru compunerea mesajului și nu este transmisă către un server al campaniei.
